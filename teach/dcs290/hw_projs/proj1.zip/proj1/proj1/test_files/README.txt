*.java: source file, i.e., input to your lexer
*.out: result file, i.e., output of your lexer

The output of your lexer should match these outputs (minor differences are fine).
