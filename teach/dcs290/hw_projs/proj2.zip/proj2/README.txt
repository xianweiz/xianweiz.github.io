proj2.pdf: document describing project 2
grading.pdf: grading sheet of project 2

src/: source files provided for you to start from
	lex.l: the lex file from your project 1 (remember to update following the instructions in proj2.pdf)
	grammar.y: the yacc file, where you should mainly write your codes
	proj2.h: the provided header file (no change needed)
	proj2.c: the provided source file with the support routines (remember to update following the instructions in proj2.pdf)
	Makefile: an example makefile to compile your codes
test_files/: example MINI-JAVA source files for testing