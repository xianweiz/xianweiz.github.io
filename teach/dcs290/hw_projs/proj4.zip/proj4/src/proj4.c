#include "proj4.h"

void gen_code(tree parseTree) {

}
