#ifndef _PROJ4_H
#define _PROJ4_H

#include "proj2.h"

void gen_code(tree parseTree);

#endif
